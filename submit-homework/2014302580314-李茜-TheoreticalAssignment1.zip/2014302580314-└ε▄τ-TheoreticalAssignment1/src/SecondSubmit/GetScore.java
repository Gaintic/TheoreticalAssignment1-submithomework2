package SecondSubmit;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class GetScore {
private String classNum;
private String className;
private String classType;
private double credit;
private String teacher;
private String department;
private String studyType;
private String year;
private String term;
private double score;

public GetScore(String num,String name,String sType,double credit, String teacher, String department,String stuType, String year, String semester, double score)
{
	this.classNum = num;
	this.className = name;
	this.classType = sType;
	this.credit = credit;
	this.teacher = teacher;
	this.department = department;
	this.studyType = stuType;
	this.year = year;
	this.term = semester;
	this.score = score;
}


	
}
