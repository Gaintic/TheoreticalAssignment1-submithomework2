package SecondSubmit;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MainGUI {
	JButton button;
	public void go(){
		JFrame  frame =new JFrame();
		button = new JButton("���");
		button.addActionListener((ActionListener) this);
		frame.getContentPane().add(button);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 300);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent event)
	{
		button.setText("�򿪳ɼ���");
		String[]s = {};
		WriteExcel.main(s);
		try {
			Runtime.getRuntime().exec("cmd /c �����ļ�");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.exit(0);
	}
	public static void main(String[] arg) {
		// TODO Auto-generated method stub
		MainGUI gui = new MainGUI();
		gui.go();
		
		
	}
		
		

}
