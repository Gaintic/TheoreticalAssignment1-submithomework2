package SecondSubmit;

import java.io.File;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;

public class WriteExcel {
	public static void main(String[] args){
		// TODO Auto-generated method stub
	   jxl.Workbook readE = null;
	   Sheet sheet = readE.getSheet(0);
 	   int rows = sheet.getRows();
 	   GetScore getscore[] = new GetScore[rows-1];
 	   
 	   	jxl.write.WritableWorkbook wwb = null;
		String fileName = "MyScore1.xls";
		wwb = Workbook.createWorkbook(new File(fileName));
		jxl.write.WritableSheet ws = wwb.createSheet("My Grade List", 0);  
		jxl.write.WritableFont wf = new jxl.write.WritableFont(jxl.write.WritableFont.ARIAL,12,jxl.write.WritableFont.NO_BOLD,false);
		jxl.write.WritableCellFormat wcf = new jxl.write. WritableCellFormat(wf);
		for (int i = 0; i < rows-2; i++){
	    		  ws.addCell(new Label(0, i + 1, getscore[i].classNum, wcf));
	    		  ws.addCell(new Label(1, i + 1, getscore[i].className, wcf));
	    		  ws.addCell(new Label(2, i + 1, getscore[i].classType, wcf));
	    		  String str1=Double.toString(getscore[i].credit);
	    		  ws.addCell(new Label(3, i + 1, str1, wcf));
	    		  ws.addCell(new Label(4, i + 1, getscore[i].teacher, wcf));
	    		  ws.addCell(new Label(5, i + 1, getscore[i].department, wcf));
	    		  ws.addCell(new Label(6, i + 1, getscore[i].studyType, wcf));
	    		  ws.addCell(new Label(7, i + 1, getscore[i].year,wcf ));
	    		  ws.addCell(new Label(8, i + 1, getscore[i].term,wcf ));
	    		  if(getscore[i].score == 0)
	    		  {
	    			  ws.addCell(new Label(9, i+1, " "));
	    		  }
	    		  else
	    		  {
	    			  String str2 = Double.toString(getscore[i].score);
	    			  ws.addCell(new Label(9, i+1, str2 ,wcf));
	    			  
	    		  }
	    	  }
	    ws.addCell(new Label(0,0,"��ͷ��",wcf));
	    ws.addCell(new Label(1,0,"�γ�����",wcf));
	    ws.addCell(new Label(2,0,"�γ�����",wcf));
	    ws.addCell(new Label(3,0,"ѧ��",wcf));
	    ws.addCell(new Label(4,0,"��ʦ",wcf));
	    ws.addCell(new Label(5,0,"�ڿ�ѧԺ",wcf));
	    ws.addCell(new Label(6,0,"ѧϰ����",wcf)); 
	    ws.addCell(new Label(7,0,"ѧ��",wcf));
	    ws.addCell(new Label(8,0,"ѧ��",wcf));
	    ws.addCell(new Label(9,0,"�ɼ�",wcf));
	    
	    //add GPA and weighed average
	    String str3 =String.format("�ҵ�ƽ���ɼ��� %f",WAverage); 
	    ws.addCell(new Label(0,rows+1,str3));
	    String str4 = String.format("�ҵ�GPA�� %f", GPA);
	    ws.addCell(new Label(0,rows+2,str4));

    wwb.write();		
	}

