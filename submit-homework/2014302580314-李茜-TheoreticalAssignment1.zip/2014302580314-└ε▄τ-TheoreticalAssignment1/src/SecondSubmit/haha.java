package SecondSubmit;
import java.io.File;   
import java.io.FileInputStream;   
import java.io.InputStream;   
import jxl.Cell;   
import jxl.CellType;    
import jxl.Sheet;   
import jxl.Workbook;   
import jxl.write.Label;   
import java.io.*;  

public class GetScore {
private String classNum;
private String className;
private String classType;
private double credit;
private String teacher;
private String department;
private String studyType;
private String year;
private String term;
private double score;

public GetScore(String num,String name,String sType,double credit, String teacher, String department,String stuType, String year, String semester, double score)
{
	this.classNum = num;
	this.className = name;
	this.classType = sType;
	this.credit = credit;
	this.teacher = teacher;
	this.department = department;
	this.studyType = stuType;
	this.year = year;
	this.term = semester;
	this.score = score;
}


public static void main(String[] args) {
	// TODO Auto-generated method stub
	 jxl.Workbook readE = null;
      
    	 //��ȡexcel�ļ�
    	   InputStream FilePath = new FileInputStream("src/MyScore.xls"); 
    	   readE = Workbook.getWorkbook(FilePath);
    	   
    	   
    	   Sheet sheet = readE.getSheet(0);
    	   int rows = sheet.getRows();
    	   
    	   GetScore getscore[] = new GetScore[rows-1];
    	  //get the data in every cells of the sheet
    	   String classNum;
    	   String className;
    	   String classType;
    	   double credit;
    	   String teacher;
    	   String department;
    	   String studyType;
    	   String year;
    	   String semester;
    	   double score;
    	   

   		
    	   
    	   for(int i= 1; i< rows-1;i++)
    	    {
    		 
    	    		Cell cell = sheet.getCell(0,i);
    	    		classNum = cell.getContents();
    	    		cell= sheet.getCell(1,i);
    	    		className = cell.getContents();
    	    		cell = sheet.getCell(2,i);
    	    		classType = cell.getContents();
    	    		cell = sheet.getCell(3, i);
	   	    		credit = Double.parseDouble(cell.getContents());
    	    		cell = sheet.getCell(4, i);
    	    		teacher = cell.getContents();
    	    		cell = sheet.getCell(5, i);
    	    		department = cell.getContents();
    	    		cell = sheet.getCell(6, i);
    	    		studyType = cell.getContents();
    	    		cell = sheet.getCell(7, i);
    	    		year = cell.getContents();
    	    		cell = sheet.getCell(8, i);
    	    		semester = cell.getContents();
    	    		cell = sheet.getCell(9, i);
    	    		if(cell.getType() == CellType.EMPTY)
    	    			score =0;
    	    		else score = Double.parseDouble(cell.getContents());
    	   
    	    		getscore[i-1] = new GetScore(classNum,className,classType,credit,teacher,department,studyType,year,semester,score);
    	    		
    	    }
    	   
    	   //����
    	   double tempD = 0.0;
    	   String tempS=null;
    	   for (int j = 0;j < rows-2;j++ )
    	   {
    		   for(int k = 1 ; j+k < rows-2; k++)
    		   {
    			   if(getscore[j].score < getscore[j+k].score)
    			   {
    				   tempS = getscore[j].classNum;
    				   getscore[j].classNum = getscore[j+k].classNum;
    				   getscore[j+k].classNum = tempS;
    				   
    				   tempS = getscore[j].className;
    				   getscore[j].className = getscore[j+k].className;
    				   getscore[j+k].className = tempS;
    				   
    				   tempS = getscore[j].classType;
    				   getscore[j].classType = getscore[j+k].classType;
    				   getscore[j+k].classType = tempS;
    				   
    				   tempD = getscore[j].credit;
    				   getscore[j].credit = getscore[j+k].credit;
    				   getscore[j+k].credit = tempD;
    				   
    				   tempS = getscore[j].teacher;
    				   getscore[j].teacher = getscore[j+k].teacher;
    				   getscore[j+k].teacher = tempS;
    				   
    				   tempS=getscore[j].department;
    				   getscore[j].department = getscore[j+k].department;
    				   getscore[j+k].department = tempS;
    				   
    				   tempS= getscore[j].studyType;
    				   getscore[j].studyType = getscore[j+k].studyType;
    				   getscore[j+k].studyType = tempS;
    				   
    				   tempS = getscore[j].year;
    				   getscore[j].year = getscore[j+k].year;
    				   getscore[j+k].year = tempS;
    				   
    				   tempS = getscore[j].term;
    				   getscore[j].term = getscore[j+k].term;
    				   getscore[j+k].term = tempS;
    				   
    				   tempD = getscore[j].score;
    				   getscore[j].score = getscore[j+k].score;
    				   getscore[j+k].score = tempD;
    			   }
    		   }
    			   
    	   }
    	
    	//����ƽ����
    	double totalcredit = 0.0;
    	double cs = 0.0;//cs: credit*score
    	int r = 0;
    	for (r = 0; r < rows-2; r++)
    	{
    		if (getscore[r].score != 0 )
    		{
    			totalcredit += getscore[r].credit;
    		}
    	}
    	for(r=0; r< rows-2;r++)
    	{
    		cs = cs+ getscore[r].score*getscore[r].credit;
    	}
    	double WAverage = 0;
    	    	
    	//����GPA
    	double cg = 0;//cg:credit*GPA
    	for(r = 1; r < rows-1; r++)
    	{
    		if(getscore[r].score>=90)
    			cg +=  getscore[r].credit*4.0;
    		else if(getscore[r].score>=85)
    			cg +=  getscore[r].credit*3.7;
    		else if(getscore[r].score>=82)
    			cg +=  getscore[r].credit*3.3;
    		else if(getscore[r].score>=78)
    			cg +=  getscore[r].credit*3.0;
    		else if(getscore[r].score>=75)
    			cg +=  getscore[r].credit*2.7;
    		else if(getscore[r].score>=72)
    			cg +=  getscore[r].credit*2.3;
    		else if(getscore[r].score>=68)
    			cg += getscore[r].credit*2.0;
    		else if(getscore[r].score>=64)
    			cg +=  getscore[r].credit*1.5;
    		else if(getscore[r].score>=60)
    			cg +=  getscore[r].credit*1.0;
    		else
    			cg+=0;
    	}
    	
    	double GPA = cg/totalcredit;
    	WAverage = cs/totalcredit;
    	System.out.println(WAverage);
    	System.out.println(GPA);
    	
	   
    	//����µ�excel
    		jxl.write.WritableWorkbook wwb = null;
	 		String fileName = "MyScore1.xls";
	 		wwb = Workbook.createWorkbook(new File(fileName));
	 		jxl.write.WritableSheet ws = wwb.createSheet("My Grade List", 0);  
	 		jxl.write.WritableFont wf = new jxl.write.WritableFont(jxl.write.WritableFont.ARIAL,12,jxl.write.WritableFont.NO_BOLD,false);
	 		jxl.write.WritableCellFormat wcf = new jxl.write. WritableCellFormat(wf);
	 		for (int i = 0; i < rows-2; i++){
	 	    		  ws.addCell(new Label(0, i + 1, getscore[i].classNum, wcf));
	 	    		  ws.addCell(new Label(1, i + 1, getscore[i].className, wcf));
	 	    		  ws.addCell(new Label(2, i + 1, getscore[i].classType, wcf));
	 	    		  String str1=Double.toString(getscore[i].credit);
	 	    		  ws.addCell(new Label(3, i + 1, str1, wcf));
	 	    		  ws.addCell(new Label(4, i + 1, getscore[i].teacher, wcf));
	 	    		  ws.addCell(new Label(5, i + 1, getscore[i].department, wcf));
	 	    		  ws.addCell(new Label(6, i + 1, getscore[i].studyType, wcf));
	 	    		  ws.addCell(new Label(7, i + 1, getscore[i].year,wcf ));
	 	    		  ws.addCell(new Label(8, i + 1, getscore[i].term,wcf ));
	 	    		  if(getscore[i].score == 0)
	 	    		  {
	 	    			  ws.addCell(new Label(9, i+1, " "));
	 	    		  }
	 	    		  else
	 	    		  {
	 	    			  String str2 = Double.toString(getscore[i].score);
	 	    			  ws.addCell(new Label(9, i+1, str2 ,wcf));
	 	    			  
	 	    		  }
	 	    	  }
	 	    ws.addCell(new Label(0,0,"��ͷ��",wcf));
	 	    ws.addCell(new Label(1,0,"�γ�����",wcf));
	 	    ws.addCell(new Label(2,0,"�γ�����",wcf));
	 	    ws.addCell(new Label(3,0,"ѧ��",wcf));
	 	    ws.addCell(new Label(4,0,"��ʦ",wcf));
	 	    ws.addCell(new Label(5,0,"�ڿ�ѧԺ",wcf));
	 	    ws.addCell(new Label(6,0,"ѧϰ����",wcf)); 
	 	    ws.addCell(new Label(7,0,"ѧ��",wcf));
	 	    ws.addCell(new Label(8,0,"ѧ��",wcf));
	 	    ws.addCell(new Label(9,0,"�ɼ�",wcf));
	 	    
	 	    //add GPA and weighed average
	 	    String str3 =String.format("My Weighed Average is %f",WAverage); 
	 	    ws.addCell(new Label(0,rows+1,str3));
	 	    String str4 = String.format("My GPA is %f", GPA);
	 	    ws.addCell(new Label(0,rows+2,str4));

            wwb.write();		
	 	}
	 	
    	
        



	
}



